package com.amazonaws.lambda.demo;

public class ResponseModel {
	  
	  private String token;
	  
	  public ResponseModel(String token) {
	    this.token = token;
	  }

	  public String getToken() {
	    return token;
	  }


	}